# yearlyreport-uipath
generation of yearly report using Robotic Enterprise Framework in UIPath
